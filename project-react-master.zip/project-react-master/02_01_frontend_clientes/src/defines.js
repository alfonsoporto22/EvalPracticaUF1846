//Ruta de las fotos
export const PATH = "http://127.0.0.1:5500/02_01_frontend_clientes/src/img/";
//Ruta de la API
export const URL = "http://localhost:3000/api";